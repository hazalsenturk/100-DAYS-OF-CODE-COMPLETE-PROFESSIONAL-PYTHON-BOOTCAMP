# Write your code below this line 👇
print("Hello world!\nHello world!\nHello world!")
print("Hello"+" Hazal")
print("Hello"+" "+"Hazal")
# input() will get user input in console
# then print() will print the "Hello" and the user input 
print("Hello "+ input("What is your name?"))